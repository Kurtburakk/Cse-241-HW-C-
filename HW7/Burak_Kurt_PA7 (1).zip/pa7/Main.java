import java.util.ArrayList;
import java.util.List;

abstract class DatasetObject
{
    protected String name;      // it hold to name
    protected String info;      // it hold to info

    public DatasetObject(String name, String info)  // constructor 
    {
        this.name = name;
        this.info = info;
    }
    public abstract void info();
}

interface Playable // create interface
{
    void play();
    void info();
}

interface NonPlayable
{
    void view();
    void info();
}

interface Visual
{
    void show();
}

interface NonVisual
{
    void display();
}

class Dataset
{
    private List<DatasetObject> objects = new ArrayList<>();    // it hold to objects
    private List<Player> players = new ArrayList<>();           // it hold to objects
    private List<Viewer> viewers = new ArrayList<>();           // it hold to objects

    public void register(Player player)     // it saves to objeects
    {
        players.add(player);
    }

    public void register(Viewer viewer)     // it saves to objeects
    {
        viewers.add(viewer);
    }

    public void unregister(Player player)   // it remove  objeects
    {
        players.remove(player);
    }

    public void unregister(Viewer viewer)
    {
        viewers.remove(viewer);
    }

    public void add(DatasetObject object)
    {
        objects.add(object);
        notifyObservers(object);
    }

    public void remove(DatasetObject object)
    {
        objects.remove(object);
        notifyObservers(object);
    }

    private void notifyObservers(DatasetObject obj) // it check objects type and annoncue relating to object
    {
        for (Player player : players) 
        {
            if (obj instanceof Playable)
            {
                player.update((Playable) obj);
            }
        }

        for (Viewer viewer : viewers)
        {
            if (obj instanceof NonPlayable)
            {
                viewer.update((NonPlayable) obj);
            }
        }
    }
}

class Image extends DatasetObject implements NonPlayable, Visual 
{
    private String dimension;

    public Image(String name, String dimension, String info) // constructor
    {
        super(name, info);
        this.dimension = dimension;
    }

    @Override
    public void info() // it print relating to part
    {
        System.out.println("Image: " + name + ", Dimension: " + dimension + ", Info: " + info);
    }

    @Override
    public void view() 
    {
        System.out.println("Viewing image: " + name);
    }

    @Override
    public void show() 
    {
        System.out.println("Showing image: " + name);
    }
}

class Audio extends DatasetObject implements Playable, NonVisual // Class representing audio objects
{
    private String duration;

    public Audio(String name, String duration, String info) // constructor
    {
        super(name, info);
        this.duration = duration;
    }

    @Override
    public void info() // it print relating to part
    {
        System.out.println("Audio: " + name + ", Duration: " + duration + ", Info: " + info);
    }

    @Override
    public void play() 
    {
        System.out.println("Playing audio: " + name);
    }

    @Override
    public void display() 
    {
        System.out.println("Displaying audio: " + name);
    }
}

class Video extends DatasetObject implements Playable, Visual // Class representing video objects
{
    private String duration;

    public Video(String name, String duration, String info) // constructor
    {
        super(name, info);
        this.duration = duration;
    }

    @Override
    public void info() // it print relating to part
    {
        System.out.println("Video: " + name + ", Duration: " + duration + ", Info: " + info);
    }

    @Override
    public void play() 
    {
        System.out.println("Playing video: " + name);
    }

    @Override
    public void show() 
    {
        System.out.println("Showing video: " + name);
    }
}

// Class representing text objects
class Text extends DatasetObject implements NonPlayable, NonVisual 
{
    public Text(String name, String info) 
    {
        super(name, info);
    }

    @Override
    public void info() 
    {
        System.out.println("Text: " + name + ", Info: " + info);
    }

    @Override
    public void view() 
    {
        System.out.println("Viewing text: " + name);
    }

    @Override
    public void display() 
    {
        System.out.println("Displaying text: " + name);
    }
}

class Player 
{
    private List<Playable> playlist = new ArrayList<>();
    private int currentIndex = -1;

    public void update(Playable obj)
    {
        if (!playlist.contains(obj))
        {
            playlist.add(obj);
        } 
        else
        {
            playlist.removeIf(item -> item.equals(obj));
        }
    }

    public Playable currentlyPlaying() 
    {
        if (currentIndex >= 0 && currentIndex < playlist.size())
        {
            return playlist.get(currentIndex);
        }
        else if(!playlist.isEmpty())
        {
            currentIndex = 0;
            return playlist.get(0);
        }
        return null;
    }

    public void showList()
    {
        for (Playable item : playlist)
        {
            item.info();
        }
    }

    public void next(String type) 
    {
        if (type.equals("audio"))
        {
            currentIndex = (currentIndex + 1) % playlist.size();
            playlist.get(currentIndex).play();
        }
        else if (type.equals("video"))
        {
            currentIndex = (currentIndex + 1) % playlist.size();
            playlist.get(currentIndex).play();
        }
    }

    public void previous(String type)
    {
        if (type.equals("audio"))
        {
            currentIndex = (currentIndex - 1 + playlist.size()) % playlist.size();
            playlist.get(currentIndex).play();
        }
        else if (type.equals("video"))
        {
            currentIndex = (currentIndex - 1 + playlist.size()) % playlist.size();
            playlist.get(currentIndex).play();
        }
    }
}

class Viewer 
{
    private List<NonPlayable> viewList = new ArrayList<>();
    private int currentIndex = -1;

    public void update(NonPlayable obj) // it update objects
    {
        if (!viewList.contains(obj))
        {
            viewList.add(obj);
        }
        else
        {
            viewList.removeIf(item -> item.equals(obj));
        }
    }
    public NonPlayable currentlyViewing()   // it retrieves the currently viewed NonPlayable object 
    {
            if (currentIndex >= 0 && currentIndex < viewList.size())
            {
                return viewList.get(currentIndex);
            }
            else if(!viewList.isEmpty())
            {
                currentIndex = 0;
                return viewList.get(0);
            }
            return null;
    }

    public void showList() // it print showlist 
    {
        for (NonPlayable item : viewList) 
        {
            item.info();
        }
    }

    public void next(String type)   // you provided allows for navigating to the next element
    {
        if (type.equals("text"))
        {
            currentIndex = (currentIndex + 1) % viewList.size();
            viewList.get(currentIndex).view();
        }
        else if (type.equals("image"))
        {
            currentIndex = (currentIndex + 1) % viewList.size();
            viewList.get(currentIndex).view();
        }
    }

    public void previous(String type)   // you provided allows for navigating to the previous element
    {
        if (type.equals("text"))
        {
            currentIndex = (currentIndex - 1 + viewList.size()) % viewList.size();
            viewList.get(currentIndex).view();
        }
        else if (type.equals("image"))
        {
            currentIndex = (currentIndex - 1 + viewList.size()) % viewList.size();
            viewList.get(currentIndex).view();
        }
    }
}

public class Main 
{
    public static void main(String[] args) 
    {
        Dataset ds = new Dataset(); // create Dataset

        Player p1 = new Player();
        Player p2 = new Player();
        Viewer v1 = new Viewer();
        Viewer v2 = new Viewer();

        ds.register(p1);    // it add dataset
        ds.register(p2);    // it add dataset
        ds.register(v1);    // it add dataset
        ds.register(v2);    // it add dataset

        ds.add(new Image("imagename1", "dimension info1", "other info1"));
        ds.add(new Image("imagename2", "dimension info2", "other info2")); 
        ds.add(new Image("imagename3", "dimension info3", "other info3")); 
        ds.add(new Image("imagename4", "dimension info4", "other info4")); 
        ds.add(new Image("imagename5", "dimension info5", "other info5"));

        ds.add(new Audio("audioname1", "duration1", "other info1")); 
        ds.add(new Audio("audioname2", "duration2", "other info2")); 
        ds.add(new Audio("audioname3", "duration3", "other info3"));

        ds.add(new Video("videoname1", "duration1", "other info1")); 
        ds.add(new Video("videoname2", "duration2", "other info2")); 
        ds.add(new Video("videoname3", "duration3", "other info3"));

        ds.add(new Text("textname1", "other info1")); 
        ds.add(new Text("textname2", "other info2")); 
        ds.add(new Text("textname3", "other info3"));

        Playable po = p1.currentlyPlaying();       // Use player object
        if (po != null) 
        {
            po.info();
        }

        NonPlayable np = v1.currentlyViewing();    // Use viewer object
        if (np != null) 
        {
            np.info();
        }
        System.out.println("Player list before remove:");
        p1.showList();  // Player shows playlist

        ds.remove((DatasetObject) po);  // Remove an object from the dataset

        System.out.println("Player list after remove:");
        
        p1.showList();  // Player shows playlist
        System.out.println("Viewer list:");        
        v1.showList(); // Viewer shows view list

        try // Player plays the next object
        {
            p1.next("text");
        } 
        catch (Exception e) 
        {
            System.out.println("Error in playing next audio: " + e.getMessage());
        }
        try     // Viewer displays the next object
        {
            v1.next("text");
        } 
        catch (Exception e) 
        {
            System.out.println("Error in viewing next text: " + e.getMessage());
        }
    }
}