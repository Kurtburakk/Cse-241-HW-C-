#include"Music.h"
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>

Music::Music()
{
}
Music::Music(const std::string& title,const std::string& artists,const std::string& year ,const std::string& genre)
:title(title),artists(artists),year(year),genre(genre)
{
}
void Music::print()const
{
    std::ofstream ofile("output.txt",std::ios::app);
    ofile << '"'<<title <<'"'<< " " << '"'<< artists <<'"'<<" "<<'"'<< year <<'"'<<" "<< '"'<< genre<<'"'<<"\n";
    ofile.close();
}

bool Music::compare(const Music &obj1, const Music &obj2, const std::string &str)
{
    if (str == "title") {
        return obj1.title < obj2.title;
    } else if (str == "artists") {
        return obj1.artists < obj2.artists;
    } else if (str == "year") {
        return obj1.year < obj2.year;
    } else if (str == "genre") {
        return obj1.genre < obj2.genre;
    }
    return false;
}
bool Music::areAnyStringsEqual()
{
            if(title == artists || title == year     || title == genre ||
            artists == year  || artists == genre  || year == genre
            )
            {
                genre="";
                return true;
            }
            return false;
}
