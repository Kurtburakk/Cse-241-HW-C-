#ifndef BOOK_H_
#define BOOK_H_

#include <string>

class Book
{
private:
    std::string title;
    std::string authors;
    std::string year;
    std::string tags;
public:
    Book();
    Book(const std::string& title,const std::string& authors,const std::string& year,const std::string& tags);
    std::string gettitle() const {return title;}
    std::string getauthors() const {return authors;}
    std::string getyear() const {return year;}
    std::string gettags() const {return tags;}
    void print()const;
    static bool compare(const Book& obj1, const Book& obj2, const std::string& str);
    bool areAnyStringsEqual();
};
#endif /*BOOK_H_*/