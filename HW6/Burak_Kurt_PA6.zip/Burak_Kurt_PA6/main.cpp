#include <iostream>
#include <fstream>
#include <string>


#include"Book.h"
#include"Music.h"
#include"Movie.h"
#include"Catalog.cpp"


int main()
{
        std::ifstream file("data.txt");
        std::string catalog_name;

        if(file.is_open())
        {
            std::getline(file,catalog_name);    // it open organiser mode according to kind of file
            catalog_name.pop_back();
            if(catalog_name=="book")
                Catalog<Book> books;
            else if(catalog_name=="music")
                Catalog<Music> musics;
            else if(catalog_name=="movie")
                Catalog<Movie> movies;
        file.close();
        }
        else
            std::cout<< "Data file not exits"<<std::endl;
}