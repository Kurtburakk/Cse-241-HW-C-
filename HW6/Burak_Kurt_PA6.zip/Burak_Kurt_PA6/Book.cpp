#include"Book.h"
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>

Book::Book()
{
}
Book::Book(const std::string& title, const std::string& authors, const std::string& year, const std::string& tags)
:title(title),authors(authors),year(year),tags(tags)
{
}
void Book::print()const
{
    std::ofstream ofile("output.txt",std::ios::app);
    ofile << '"'<<title <<'"'<< " " << '"'<< authors <<'"'<<" "<<'"'<< year <<'"'<<" "<< '"'<< tags<<'"'<<"\n";
    ofile.close();
}

bool Book::compare(const Book& obj1, const Book& obj2, const std::string& str) {
    if (str == "title") {
        return obj1.title < obj2.title;
    } else if (str == "authors") {
        return obj1.authors < obj2.authors;
    } else if (str == "year") {
        return obj1.year < obj2.year;
    } else if (str == "tags") {
        return obj1.tags < obj2.tags;
    }
    return false;
}
bool Book::areAnyStringsEqual()
{
          if(title == authors  || title == year    || title == tags ||
             authors == year   || authors == tags  || year == tags
            )
            {
                tags="";
                return true;
            }
            return false;
}