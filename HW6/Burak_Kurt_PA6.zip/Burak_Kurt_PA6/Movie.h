#ifndef MOVIE_H_
#define MOVIE_H_

#include <vector>
#include <string>

class Movie
{
private:
    std::string title;
    std::string director;
    std::string year; 
    std::string genre;
    std::string starring;
public:
    Movie();    //default constructor
    Movie(const std::string& title, const std::string& director, const std::string& year, const std::string& genre, const std::string& starring);
    std::string gettitle() const {return title;}    //return type
    std::string getdirector() const {return director;}
    std::string getyear() const {return year;}
    std::string getgenre() const {return genre;}
    std::string getstarring() const {return starring;}
    void print()const;
    static bool compare(const Movie& obj1, const Movie& obj2, const std::string& str);  // compare two objects
    bool areAnyStringsEqual();  // check empty string
};

#endif /*MOVIE_H_*/