#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>

using std::cout;
using std::endl;

#include"Book.h"
#include"Music.h"
#include"Movie.h"

template<typename T>
class Catalog
{
private:
    std::vector<T> catalogs;    // hold to objects
    std::string catalog_name;   // hold to catalog name 
    std::vector<int>del_index;  // this part hold will delete objects index
    std::vector<Book> bocatalogs;
    std::vector<Music> mucatalogs;
    std::vector<Movie> mocatalogs;
public:
    Catalog();
    void create();              // read data.txt and create objects
    void command();             // read command.txt and apply operations
    void expection();           // it check same entry
    void expection_missing();   // it check empty field
    void search(const std::string& field,const std::string& keyword);   // search algoritm
    void sort(const std::string& str);                                  // sort algoritm    
    void print();                                                       // print all objects    
};

template<typename T>
Catalog<T>::Catalog()
{
    create();
}
template<typename T>
void Catalog<T>::create()
{   
    std::ifstream file("data.txt");
    std::vector<std::string> catalog_temp;
    std::string line;
    std::string temp;
    std::string temp_info;
    
    if(file.is_open())
    {
        std::getline(file,catalog_name);
        catalog_name.pop_back();        // fix string 
        std::ofstream ofile;
        ofile.open("output.txt",std::ios::app);
        ofile<<"Catalog Read: "<< catalog_name << "\n";     // it print kind of catalog 
        ofile.close();
        int i=0,a=0;

        while (std::getline(file, line))    // this part read file and hold to field in vector
        {
            catalog_temp.clear();
            std::istringstream split_line(line);
            getline(split_line, temp, '\"');
            getline(split_line, temp_info, '\"');
            catalog_temp.push_back(temp_info);
            getline(split_line, temp, '\"');
            getline(split_line, temp_info, '\"');
            catalog_temp.push_back(temp_info);
            getline(split_line, temp, '\"');
            getline(split_line, temp_info, '\"');
            catalog_temp.push_back(temp_info);
            getline(split_line, temp, '\"');
            getline(split_line, temp_info, '\"');
            catalog_temp.push_back(temp_info);
            if(catalog_name=="movie")
            {
            getline(split_line, temp, '\"');
            getline(split_line, temp_info, '\"');
            catalog_temp.push_back(temp_info);    
            }
            if(catalog_name=="movie")       // it open vector mode according to kind of file
            {
                Movie mo(catalog_temp[0],catalog_temp[1],catalog_temp[2],catalog_temp[3],catalog_temp[4]);
                mocatalogs.push_back(mo);
            }
            else if(catalog_name=="music")
            {
                Music mu(catalog_temp[0],catalog_temp[1],catalog_temp[2],catalog_temp[3]);
                mucatalogs.push_back(mu);
            }
            else if(catalog_name=="book")
            {
                Book bo(catalog_temp[0],catalog_temp[1],catalog_temp[2],catalog_temp[3]);
                bocatalogs.push_back(bo);
            }
        }
        expection();
        expection_missing();
        ofile.open("output.txt",std::ios::app);     
        if(catalog_name=="movie")
            ofile<<mocatalogs.size()<<" unique entries"<<"\n";  // it print correct entry
        else if(catalog_name=="music")
            ofile<<mucatalogs.size()<<" unique entries"<<"\n";
        else if(catalog_name=="book")
            ofile<<bocatalogs.size()<<" unique entries"<<"\n";
        ofile.close();  
        command();
    }
    else
    {
        cout<<"Data file not exits."<<endl;
    } 
}
template<typename T>
void Catalog<T>::print()            // print all entry
{
    if(catalog_name=="book")
    {
        for (int i = 0; i < bocatalogs.size(); i++)
            bocatalogs[i].print();
    }
    else if(catalog_name=="music")
    {
        for (int i = 0; i < mucatalogs.size(); i++)
            mucatalogs[i].print();
    }
    else if(catalog_name=="movie")
    {
        for (int i = 0; i < mocatalogs.size(); i++)
            mocatalogs[i].print();
    }
}
template<typename T>
void Catalog<T>::expection()
{
    del_index.clear();
    int i=0,j=0;

    if(catalog_name=="book")
    {
        for (i = 0; i < bocatalogs.size(); i++)     // this part check same entry
        {
            for (j = i + 1; j < bocatalogs.size(); j++)
            {
                try 
                {   
                    if (bocatalogs[i].gettitle() == bocatalogs[j].gettitle())
                    {
                        del_index.push_back(j);
                        throw std::runtime_error("Exception: Duplicate entry");
                    }
                }
                catch (const std::exception& e)
                {
                    std::ofstream ofile("output.txt",std::ios::app);
                    ofile << e.what() << "\n";
                    ofile.close();
                    bocatalogs[j].print();
                }
            }
        }
        for(int i=0;i<del_index.size();i++)
        bocatalogs.erase(bocatalogs.begin()+del_index[i] - i);
    }

    else if(catalog_name=="music")
    {
        for (i = 0; i < mucatalogs.size(); i++)
        {
            for (j = i + 1; j < mucatalogs.size(); j++)
            {
                try 
                {   
                    if (mucatalogs[i].gettitle() == mucatalogs[j].gettitle())
                    {
                        del_index.push_back(j);
                        throw std::runtime_error("Exception: Duplicate entry");
                    }
                }
                catch (const std::exception& e)
                {
                    std::ofstream ofile("output.txt",std::ios::app);
                    ofile <<e.what() << "\n";
                    ofile.close();
                    mucatalogs[j].print();
                }
            }
        }
        for(int i=0;i<del_index.size();i++)
        mucatalogs.erase(mucatalogs.begin()+del_index[i] - i);
    }

    else if(catalog_name=="movie")
    {
        for (i = 0; i < mocatalogs.size(); i++)
        {
            for (j = i + 1; j < mocatalogs.size(); j++)
            {
                try 
                {   
                    if (mocatalogs[i].gettitle() == mocatalogs[j].gettitle())
                    {
                        del_index.push_back(j);
                        throw std::runtime_error("Exception: Duplicate entry");
                    }
                }
                catch (const std::exception& e)
                {
                    std::ofstream ofile("output.txt",std::ios::app);
                    ofile <<e.what() << "\n";
                    ofile.close();
                    mocatalogs[j].print();
                }
            }
        }
        for(int i=0;i<del_index.size();i++)
        mocatalogs.erase(mocatalogs.begin()+del_index[i] - i);
    }
}
template<typename T>
void Catalog<T>::expection_missing()
{
    del_index.clear();
    int i=0;
    if(catalog_name=="book")
    {
        for (i = 0; i < bocatalogs.size(); i++)
        {
            try 
            {   
                if (bocatalogs[i].areAnyStringsEqual())     // this part check empty field
                {
                    del_index.push_back(i);
                    throw std::runtime_error("Exception: missing field");
                }
            }
            catch (const std::exception& e)
            {
                std::ofstream ofile("output.txt",std::ios::app);
                ofile <<e.what() << "\n";
                ofile.close();
                bocatalogs[i].print();
            }
        }
        for(int i=0;i<del_index.size();i++)
        bocatalogs.erase(bocatalogs.begin()+del_index[i] - i);
    }
    else if(catalog_name=="music")
    {
        for (i = 0; i < mucatalogs.size(); i++)
        {
            try 
            {   
                if (mucatalogs[i].areAnyStringsEqual())
                {
                    del_index.push_back(i);
                    throw std::runtime_error("Exception: missing field");
                }
            }
            catch (const std::exception& e)
            {
                std::ofstream ofile("output.txt",std::ios::app);
                ofile <<e.what() << "\n";
                ofile.close();
                mucatalogs[i].print();
            }
        }
        for(int i=0;i<del_index.size();i++)
        mucatalogs.erase(mucatalogs.begin()+del_index[i] - i);
    }
    else if(catalog_name=="movie")
    {
        for (i = 0; i < mocatalogs.size(); i++)
        {
            try 
            {   
                if (mocatalogs[i].areAnyStringsEqual())
                {
                    del_index.push_back(i);
                    throw std::runtime_error("Exception: missing field");
                }
            }
            catch (const std::exception& e)
            {
                std::ofstream ofile("output.txt",std::ios::app);
                ofile <<e.what() << "\n";
                ofile.close();
                mocatalogs[i].print();
            }
        }
        for(int i=0;i<del_index.size();i++)
        mocatalogs.erase(mocatalogs.begin()+del_index[i] - i);
    }
}

template<typename T>
void Catalog<T>::sort(const std::string& str)
{
    if(catalog_name=="book")
    {
        std::sort(bocatalogs.begin(), bocatalogs.end(), [str](const Book& obj1, const Book& obj2)   // this part sort algoritm
        {
            return Book::compare(obj1, obj2,str);
        });
    }
    else if(catalog_name=="music")
    {
        std::sort(mucatalogs.begin(), mucatalogs.end(), [str](const Music& obj1, const Music& obj2)
        {
            return Music::compare(obj1, obj2,str);
        });
    }
    else if(catalog_name=="movie")
    {
        std::sort(mocatalogs.begin(), mocatalogs.end(), [str](const Movie& obj1, const Movie& obj2)
        {
            return Movie::compare(obj1, obj2,str);
        });
    }
}
template<typename T>
void Catalog<T>::search(const std::string& field,const std::string& keyword)
{
    int found=0;
    if(catalog_name=="book")
    {
            if(field=="title")
            {
                for (const auto& book : bocatalogs) 
                {
                    if (book.gettitle().find(keyword) != std::string::npos) // it check all field for find word 
                    {
                        book.print();
                        found=1;
                        break;
                    }
                }
            }
            else if(field=="authors")
            {
                for (const auto& book : bocatalogs) 
                {
                    if (book.getauthors().find(keyword) != std::string::npos)
                    {
                        book.print();
                        found=1;
                        break;
                    }
                }
            }
            else if(field=="year")
            {
                for (const auto& book : bocatalogs) 
                {
                    if (book.getyear().find(keyword) != std::string::npos)
                    {
                        book.print();
                        found=1;
                        break;
                    }
                }
            }
            else if(field=="tags")
            {
                for (const auto& book : bocatalogs) 
                {
                    if (book.gettags().find(keyword) != std::string::npos)
                    {
                        book.print();
                        found=1;
                        break;
                    }
                }
            }
    }
    else if(catalog_name=="music")
    {
            if(field=="title")
            {
                for (const auto& music : mucatalogs) 
                {
                    if (music.gettitle().find(keyword) != std::string::npos)
                    {
                        music.print();
                        found=1;
                        break;
                    }
                }
            }
            else if(field=="artists")
            {
                for (const auto& music : mucatalogs) 
                {
                    if (music.getartists().find(keyword) != std::string::npos)
                    {
                        music.print();
                        found=1;
                        break;
                    }
                }
            }
            else if(field=="year")
            {
                for (const auto& music : mucatalogs) 
                {
                    if (music.getyear().find(keyword) != std::string::npos)
                    {
                        music.print();
                        found=1;
                        break;
                    }
                }
            }
            else if(field=="genre")
            {
                for (const auto& music : mucatalogs) 
                {
                    if (music.getgenre().find(keyword) != std::string::npos)
                    {
                        music.print();
                        found=1;
                        break;
                    }
                }
            }
    }
    else if(catalog_name=="movie")
    {
            if(field=="title")
            {
                for (const auto& movie : mocatalogs) 
                {
                    if (movie.gettitle().find(keyword) != std::string::npos)
                    {
                        movie.print();
                        found=1;
                        break;
                    }
                }
            }
            else if(field=="director")
            {
                for (const auto& movie : mocatalogs) 
                {
                    if (movie.getdirector().find(keyword) != std::string::npos)
                    {
                        movie.print();
                        found=1;
                        break;
                    }
                }
            }
            else if(field=="year")
            {
                for (const auto& movie : mocatalogs) 
                {
                    if (movie.getyear().find(keyword) != std::string::npos)
                    {
                        movie.print();
                        found=1;
                        break;
                    }
                }
            }
            else if(field=="genre")
            {
                for (const auto& movie : mocatalogs) 
                {
                    if (movie.getgenre().find(keyword) != std::string::npos)
                    {
                        movie.print();
                        found=1;
                        break;
                    }
                }
            }
            else if(field=="starring")
            {
                for (const auto& movie : mocatalogs) 
                {
                    if (movie.getstarring().find(keyword) != std::string::npos)
                    {
                        movie.print();
                        found=1;
                        break;
                    }
                }
            }
    }
}
template<typename T>
void Catalog<T>::command()
{
    std::ifstream file("command.txt");
    std::vector<std::string> split_line;    // it read command.txt and hold to string vector
    std::string info_line;
    int check=1;
    if(file.is_open())
    {
        std::string line;
        while (getline(file, line)) 
        {
            check=1;
            split_line.clear();
            std::istringstream split(line);
            while (split >> info_line) 
            {
                split_line.push_back(info_line);
            }
            if(split_line[0]=="search")
            {
                split_line[1].erase(0,1);   // delete "" 
                split_line[1].pop_back();
                split_line[3].erase(0,1);
                split_line[3].pop_back();
                if(catalog_name=="book")
                {
                    try 
                    {
                        if (!(split_line[3]=="title"||split_line[3]=="authors"||split_line[3]=="year"||split_line[3]=="tags")) //it check correct word
                            throw std::runtime_error("Exception: command is wrong");
                    }
                    catch (const std::exception& e)
                    {
                        std::ofstream ofile("output.txt",std::ios::app);
                        ofile <<e.what() << "\n";
                        ofile <<line << "\n";
                        ofile.close();
                        check=0;
                    }
                }
                else if(catalog_name=="music")
                {
                    try 
                    {
                        if (!(split_line[3]=="title"||split_line[3]=="artists"||split_line[3]=="year"||split_line[3]=="genre"))
                            throw std::runtime_error("Exception: command is wrong");
                    }
                    catch (const std::exception& e)
                    {
                        std::ofstream ofile("output.txt",std::ios::app);
                        ofile <<e.what() << "\n";
                        ofile <<line << "\n";
                        ofile.close();
                        check=0;
                    }
                }
                else if(catalog_name=="movie")
                {
                    try 
                    {
                        if (!(split_line[3]=="title"||split_line[3]=="director"||split_line[3]=="year"||split_line[3]=="genre"||split_line[3]=="starring"))
                            throw std::runtime_error("Exception: command is wrong");
                    }
                    catch (const std::exception& e)
                    {
                        std::ofstream ofile("output.txt",std::ios::app);
                        ofile <<e.what() << "\n";
                        ofile <<line << "\n";
                        ofile.close();
                        check=0;
                    }
                }
                if(check==1)
                {                std::ofstream ofile("output.txt",std::ios::app);
                    ofile <<line << "\n";
                ofile.close();
                    search(split_line[3],split_line[1]);
                }
            }
            if(split_line[0]=="sort")
            {
                split_line[1].erase(0,1); // delete "" 
                split_line[1].pop_back();
                if(catalog_name=="book")
                {
                    try 
                    {
                        if (!(split_line[1]=="title"||split_line[1]=="authors"||split_line[1]=="year"||split_line[1]=="tags")) // it check correct word
                            throw std::runtime_error("Exception: command is wrong");
                    }
                    catch (const std::exception& e)
                    {
                        std::ofstream ofile("output.txt",std::ios::app);
                        ofile <<e.what() << "\n";
                        ofile <<line << "\n";
                        ofile.close();
                        check=0;
                    }
                }
                else if(catalog_name=="music")
                {
                    try 
                    {
                        if (!(split_line[1]=="title"||split_line[1]=="artists"||split_line[1]=="year"||split_line[1]=="genre"))
                            throw std::runtime_error("Exception: command is wrong");
                    }
                    catch (const std::exception& e)
                    {
                        std::ofstream ofile("output.txt",std::ios::app);
                        ofile <<e.what() << "\n";
                        ofile <<line << "\n";
                        ofile.close();
                        check=0;
                    }
                }
                else if(catalog_name=="movie")
                {
                    try 
                    {
                        if (!(split_line[1]=="title"||split_line[1]=="director"||split_line[1]=="year"||split_line[1]=="genre"||split_line[1]=="starring"))
                            throw std::runtime_error("Exception: command is wrong");
                    }
                    catch (const std::exception& e)
                    {
                        std::ofstream ofile("output.txt",std::ios::app);
                        ofile <<e.what() << "\n";
                        ofile <<line << "\n";
                        ofile.close();
                        check=0;
                    }
                }
                if(check==1)
                {
                    std::ofstream ofile("output.txt",std::ios::app);
                    ofile <<line << "\n";
                    ofile.close();
                    sort(split_line[1]);    // sort algoritm 
                    print();                // and print all objects
                }
            }
        }
        file.close();
    }
    else
    {
        cout<<"Command file not exits."<<endl;
    }
}
