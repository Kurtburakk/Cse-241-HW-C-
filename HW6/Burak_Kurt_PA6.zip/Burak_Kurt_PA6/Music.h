#ifndef MUSIC_H_
#define MUSIC_H_

#include <vector>
#include <string>

class Music
{
private:
    std::string title;
    std::string artists;
    std::string year; 
    std::string genre;
public:
    Music();
    Music(const std::string& title, const std::string& artists, const std::string& year, const std::string& genre);
    std::string gettitle() const {return title;}
    std::string getartists() const {return artists;}
    std::string getyear() const {return year;}
    std::string getgenre() const {return genre;}
    void print()const;          // write file
    static bool compare(const Music& obj1, const Music& obj2, const std::string& str);  // it compare two objects
    bool areAnyStringsEqual();  // it check empty string
};

#endif /*MUSIC_H_*/