#include"Movie.h"
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>

Movie::Movie()
{
}
Movie::Movie(const std::string& title, const std::string& director,const std::string& year, const std::string& genre, const std::string& starring)
:title(title),director(director),year(year),genre(genre),starring(starring)
{
}
void Movie::print() const
{
    std::ofstream ofile("output.txt",std::ios::app);
    ofile << '"'<<title <<'"'<< " " << '"'<< director <<'"'<<" "<<'"'<< year <<'"'<<" "<< '"'<< genre<<'"'<<" "<< '"'<<starring<<'"'<<"\n";
    ofile.close();
}

bool Movie::compare(const Movie &obj1, const Movie &obj2, const std::string &str)
{
    if (str == "title") {
        return obj1.title < obj2.title;
    } else if (str == "director") {
        return obj1.director < obj2.director;
    } else if (str == "year") {
        return obj1.year < obj2.year;
    } else if (str == "genre") {
        return obj1.genre < obj2.genre;
    }else if (str == "starring") {
        return obj1.starring < obj2.starring;
    }
    return false;       // it compare objects for sort algoritm 
}
bool Movie::areAnyStringsEqual()
{
            if(title == director    || title == year    || title == genre ||
            title == starring    || director == year || director == genre ||
            director == starring || year == genre    || year == starring  || 
            genre == starring )
            {
                starring="";
                return true;    //it check same string 
            }
            return false;
}