#ifndef _Course_h_
#define _Course_h_

#include "Student.hpp"
#include "SchoolManagementSystem.hpp"
namespace PA4
{
class Student;

class Course
{
private:
    int order;      // course order
    string code;    // course code
    string name;    // course name
    Student* students=nullptr;      // it hold that courses's take student
    unsigned int capacity;          // students number

public:
    Course();                                   // default constructor
    Course(int order,string code,string name);  // parameter constructor
    Course(const Course& Obj);                  // copy constructor 
    ~Course();                                  // destructor
    Course& operator=(const Course& rObj);      // assignment operator
    void addCourse_to_student(const Student& studentObj); // added course to a student
    //bool dropStudent_from_course(const Student& sObj);    
    string getName()const;                                //getter function
    string getCode()const;              
    int getCapacity()const;
};
}

#endif /* _Course_h_ */

/*
    const Course* getAddress() const;
    const Course* Course::getAddress() const
{
    return this;
}
*/