#ifndef _Student_h_
#define _Student_h_

#include "Course.hpp"
#include "SchoolManagementSystem.hpp"
namespace PA4
{
class Course;

class Student
{
private:
    string name;                // student name
    int ID;                     // student ID
    Course* courses=nullptr;    // it hold that student's take courses
    unsigned int capacity;      // courses number

public:
    Student();                      //default constructor
    Student(string name,int ID);    //parameter consturctor  
    Student(const Student& Obj);    //copy consturctor
    ~Student();                     // destructor
    Student& operator=(const Student& rObj);    // assignment operator
    void addStudent_to_course(const Course& courseObj); // add student to course
    string getName()const;                  // getter function
    int getID()const;
    int getCapacity()const;
};
}

#endif /* _Student_h_ */

/*
    const Student* getAddress() const;
    
    const Student* Student::getAddress() const
{
    return this;
}
*/