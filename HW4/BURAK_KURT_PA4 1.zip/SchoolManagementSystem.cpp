#include "SchoolManagementSystem.hpp"
namespace PA4
{

SchoolManagementSystem::SchoolManagementSystem():number_Student(5),number_Course(5),used_Student(0),used_Course(0)
{
    // default constructor
    students = new Student [number_Student];
    courses = new Course [number_Course];
}

SchoolManagementSystem::SchoolManagementSystem(const SchoolManagementSystem& Obj)
{
    this->number_Student = Obj.number_Student;
    this->number_Course = Obj.number_Course;
    this->used_Student = Obj.used_Student;
    this->used_Course = Obj.used_Course;

    if(number_Student>0)
    {
        delete [] students;
        students = new Student [number_Student];  // delete old objects
        for(int i=0;i<number_Student;++i)
            students[i]=Obj.students[i];        // added new objects
    }

    if(number_Course>0)
    {
        delete [] courses;
        courses = new Course [number_Course];  // delete old objects
        for(int i=0;i<number_Course;++i)
            courses[i]=Obj.courses[i];             // added new objects    
    }
}

SchoolManagementSystem& SchoolManagementSystem::operator=(const SchoolManagementSystem &rObj)
{
    this->number_Student = rObj.number_Student;
    this->number_Course = rObj.number_Course;
    this->used_Student = rObj.used_Student;
    this->used_Course = rObj.used_Course;

    if(number_Student>0)
    {
        delete [] students;                         // delete old objects
        students = new Student [number_Student];  
        for(int i=0;i<number_Student;++i)
            students[i]=rObj.students[i];           // added new objects
    }

    if(number_Course>0)
    {
        delete [] courses;
        courses = new Course [number_Course];  // delete old objects
        for(int i=0;i<number_Course;++i)
            courses[i]=rObj.courses[i];         // added new objects
    }
    return *this;
}

void SchoolManagementSystem::increase_capacity_student()
{
    Student* temp= new Student [number_Student];        //temp dynamic array
    for(int i=0;i<number_Student;i++)
        temp[i]=students[i];
    delete [] students;
    students= new Student [number_Student+3];           // create new courses array
    for(int i=0;i<number_Student;i++)
        students[i]=temp[i];                            // added old object
    delete [] temp;
    number_Student+=3;                                  // increase capacity
}
void SchoolManagementSystem::increase_capacity_course()
{
    Course* temp= new Course [number_Course];   //temp dynamic array
    for(int i=0;i<number_Course;i++)
        temp[i]=courses[i];
    delete [] courses;  
    courses= new Course [number_Course+3];      // create new courses array
    for(int i=0;i<number_Course;i++)
        courses[i]=temp[i];                     // added old object
    delete [] temp;
    number_Course+=3;                           // increase capacity
}

void SchoolManagementSystem::list_all_students()
{
    for(int i=0;i<used_Student;i++)
        cout << students[i].getName() << " " << students[i].getID() << endl; // list all student
}

void SchoolManagementSystem::list_all_courses()
{
    for(int i=0;i<used_Course;i++)
        cout << i+1 << " " <<courses[i].getCode() << " " <<courses[i].getName() << endl; // list all courses
}

int SchoolManagementSystem::get_number_Student() const
{
    return number_Student;
}

int SchoolManagementSystem::get_number_Course() const
{
    return number_Course;
}

void SchoolManagementSystem::menu()
{
    int input;
    do
    {
        cout <<"Main_menu"<<endl;
        cout <<"0 exit"<<endl;
        cout <<"1 student"<<endl;
        cout <<"2 course"<<endl;
        cout <<"3 list_all_students"<<endl;
        cout <<"4 list_all_courses"<<endl;
        do
        {    
        cin >> input;
        }while((input<0)||(input>4));  // check input
        
        if(input==0)
        {
        exit(0);
        }
        else if(input==1)
        {
            int input1;
            do
            {
                cout <<"0 up"<<endl;
                cout <<"1 add_student"<<endl;
                cout <<"1 select_student"<<endl;
                cin >> input1;
                if(input1==1)
                {
                    cin.ignore();

                    int ID;
                    string name;
                    string input;
                    name = "";
                    while (std::cin >> input)
                    {
                        std::istringstream ss(input);
                        if (ss >> ID)
                        {
                            break;
                        }
                        if (!name.empty())
                        {
                            name += " ";
                        }
                        name += input;
                    }
                    if(used_Student==number_Student)
                    increase_capacity_student();

                    students[used_Student] = Student(name,ID);
                    used_Student++;                    
                }
                if(input1==2)
                {
                    int input3;
                    
                    do
                    {
                        cout <<"0 up"<<endl;
                        cout <<"1 delete_student"<<endl;
                        cout <<"3 add_selected_student_to_a_course"<<endl;
                        cout <<"4 drop_selected_student_from_a_course"<<endl;
                        cin >> input3;
                        if(input3==1)
                        {
                        /*    for(int i=0;i<used_Student;i++)
                            {
                                if ((s_name.compare(students[i].getName()) == 0) &&(s_ID.compare(students[i].getID()) == 0))
                                {
                                    for (int j = i; j < used_Student-1; j++) 
                                        students[j] = students[j+1];
                                    used_Student-=1;      
                                }

                            }*/
                        }
                        if(input3==1)
                        {

                        }
                        if(input3==1)
                        {

                        }
                    }while(input3!=0);



                }
            }while(input1!=0);
        }
        else if(input==2)
        {
            int input2;
            do
            {
                cout <<"0 up"<<endl;
                cout <<"1 add_course"<<endl;
                cout <<"2 select_course"<<endl;
                cin >> input2;
                if(input2==1)
                {             
                    string code;
                    string name;
                    cin >> code;
                    getline(std::cin >> std::ws, name);

                    if(used_Course==number_Course)
                    increase_capacity_course();

                    courses[used_Course] = Course(used_Course+1,code,name);
                    used_Course++;
                        
                }
                if(input2==2)
                {

                }
        
            }while(input2!=0);
        }
        else if(input==3)
            list_all_students();
        else if(input==4)
            list_all_courses();

    }while(input!=0);
    
}
}