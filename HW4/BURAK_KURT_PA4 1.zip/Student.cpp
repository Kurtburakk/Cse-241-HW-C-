#include "Student.hpp"
namespace PA4
{

Student::Student():capacity(0)
{
    // default constructor
}

Student::Student(string name, int ID):name(name),ID(ID)
{
    // parameter consturctor
}

Student::Student(const Student& Obj)
{
    this->name=Obj.name;
    this->ID=Obj.ID;
    this->capacity=Obj.capacity;

    if(capacity>0)
    {
        delete [] courses;
        courses = new Course [capacity];  
        for(int i=0;i<capacity;++i)
            courses[i]=Obj.courses[i];   
    }
}

Student::~Student()
{
    if(capacity!=0)
    delete [] courses;
}

Student& Student::operator=(const Student &rObj)
{
    this->name=rObj.name;
    this->ID=rObj.ID;
    this->capacity=rObj.capacity;

    if(capacity>0)
    {
        delete [] courses;
        courses = new Course [capacity];  
        for(int i=0;i<capacity;++i)
            courses[i]=rObj.courses[i];   
    }
    return *this;
}

void Student::addStudent_to_course(const Course& courseObj)
{
    if(capacity==0) // zero course
    {
        courses = new Course [1];
        courses[0] = courseObj;
        capacity++; 
    }
    else
    {
        Course* temp= new Course [capacity]; // temp dynamic array
        for(int i=0;i<capacity;i++)     
            temp[i]=courses[i];
        delete [] courses;                  // delete old array
        courses= new Course [capacity+1];
        for(int i=0;i<capacity;i++)
            courses[i]=temp[i];
        delete [] temp;
        courses[capacity]= courseObj;   //added new course
        capacity++;
    }
}

string Student::getName() const
{
    return this->name;
}

int Student::getID() const
{
    return this->ID;
}

int Student::getCapacity() const
{
    return this->capacity;
}
}