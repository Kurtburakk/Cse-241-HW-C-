#ifndef _SchoolManagementSystem_h_
#define _SchoolManagementSystem_h_

#include <iostream>
#include <string>
#include <sstream>
#include <cstring>

using std::cout;
using std::cin;
using std::endl;
using std::string;

#include "Student.hpp"
#include "Course.hpp"

namespace PA4
{

class Student;
class Course;

class SchoolManagementSystem
{
private:
    unsigned int number_Student; // student capacity
    unsigned int number_Course;  // course capacity
    unsigned int used_Student;   // order student
    unsigned int used_Course;    // order course
    Student* students=nullptr;   // student dynamic array
    Course* courses=nullptr;    // course dynamic array
public:
    SchoolManagementSystem();   //default constructor
    SchoolManagementSystem(const SchoolManagementSystem& Obj);  // copy constructor
    SchoolManagementSystem& operator=(const SchoolManagementSystem& rObj);  // assignment constructor
    void increase_capacity_student();   // increase student capacity
    void increase_capacity_course();    // increase course capacity
    void list_all_students();           // list all student
    void list_all_courses();            // list all courses
    int get_number_Student() const;     
    int get_number_Course() const;
    void menu();
};

}
#endif /* _SchoolManagementSystem_h_ */