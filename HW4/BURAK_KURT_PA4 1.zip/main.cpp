#include "Student.hpp"
#include "Course.hpp"
#include "SchoolManagementSystem.hpp"

int main()
{
    PA4::SchoolManagementSystem obj;
    obj.menu();
    return 0;
}