#include "Course.hpp"
namespace PA4
{

Course::Course():capacity(0)
{
    // default constructor
}

Course::Course(int order,string code, string name):order(order),code(code),name(name)
{
    // parameter constructor
}

Course::Course(const Course& Obj)           
{
    this->name=Obj.name;
    this->order=Obj.order;
    this->code=Obj.code;
    this->capacity=Obj.capacity;

    if(capacity>0)
    {
        delete [] students;
        students = new Student [capacity];
        for(int i=0;i<capacity;++i)
            students[i]=Obj.students[i];  
    }
}

Course::~Course()
{
    delete [] students;
}

Course& Course::operator=(const Course &rObj)       // assignmet operator
{
    this->name=rObj.name;
    this->code=rObj.code;
    this->order=rObj.order;
    this->capacity=rObj.capacity;

    if(capacity>0)
    {
        delete [] students;
        students = new Student [capacity];  
        for(int i=0;i<capacity;++i)
            students[i]=rObj.students[i];   
    }
    return *this;
}

void Course::addCourse_to_student(const Student& studentObj)
{
    if(capacity==0)
    {
        students = new Student [1]; //if capacity zero
        students[0] = studentObj;
        capacity++; 
    }
    else
    {
        Student* temp= new Student [capacity]; // temp dynamic array
        for(int i=0;i<capacity;i++)
            temp[i]=students[i];                // hold old student
        delete [] students;
        students= new Student [capacity+1];
        for(int i=0;i<capacity;i++)
            students[i]=temp[i];
        delete [] temp;
        students[capacity] = studentObj;        // add new student
        capacity++;
    }
}

string Course::getName() const
{
    return this->name;
}

string Course::getCode() const
{
    return this->code;
}

int Course::getCapacity() const
{
    return this->capacity;
}
}