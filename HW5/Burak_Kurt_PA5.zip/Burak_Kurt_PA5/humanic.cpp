#include "humanic.hpp"
#include "Robot.hpp"

humanic::humanic()
{
}
humanic::humanic(int newStrength, int newHit, string name) : Robot(3, newStrength, newHit, name)
{
}
int humanic::getDamage()
{
    int damage = Robot::getDamage();
    int nukeDamage=50;
    if(rand() % 10 < 10) 
        return damage + nukeDamage;         // %10 change a tactical nuke attack
    else 
        return damage;                      
}
