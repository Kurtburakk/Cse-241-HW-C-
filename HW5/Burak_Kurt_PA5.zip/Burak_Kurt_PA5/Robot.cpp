#include "Robot.hpp"

Robot::Robot() : type(1), strength(15), hitpoint(15) {}

Robot::Robot(int newType, int newStrength, int newHit, std::string newName)
{
    type = newType;
    strength = newStrength;
    hitpoint = newHit;
    name = newName;
}
Robot::~Robot()
{
}
std::string Robot::getType()        // return robot type
{
    switch (type)
    {
    case 0:
        return "optimusprime";
    case 1:
        return "robocop";
    case 2:
        return "roomba";
    case 3:
        return "bulldozer";
    }
    return "unknown";
}
int Robot::getDamage()
{
    int  damage = (rand() % strength) + 1;  // calculate robots damage
    return damage;
}