#ifndef BULLDOZER_H
#define BULLDOZER_H

#include "Robot.hpp"

class bulldozer : public Robot 
{
public:
    bulldozer(int creation_sequence_number);
    string getType() override;
    int getDamage() override;
    int getHitpoint()override;
    void decreaseHitpoint(int damage)override;  
};

#endif 
