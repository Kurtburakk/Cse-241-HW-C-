#ifndef ROBOCOP_H
#define ROBOCOP_H

#include "humanic.hpp"

class robocop : public humanic 
{
public:
    robocop(int creation_sequence_number);
    string getType() override;
    int getDamage() override;
    int getHitpoint()override;
    void decreaseHitpoint(int damage)override;
};

#endif
