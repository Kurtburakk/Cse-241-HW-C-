#include "world.hpp"
#include <iostream>

int main()
{
    World w1;
    w1.start_war();
    return 0;
}
