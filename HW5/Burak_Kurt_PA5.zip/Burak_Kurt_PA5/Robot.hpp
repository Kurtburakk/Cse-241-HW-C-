#ifndef ROBOT_H
#define ROBOT_H

#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::string;

class Robot
{
public:
    Robot();                                                                // default constructor
    Robot(int newType, int newStrength, int newHit, std::string newName);   // parameter constructor
    virtual ~Robot();                                                       // destructor
    virtual string getType();                                               // return robot name
    virtual int getDamage();                                                // return damge
    virtual int getHitpoint()= 0;                                           // return hitpoint
    virtual void decreaseHitpoint(int damage)= 0;                           // decrease hitpoint

protected:
    int strength;  
    int hitpoint;
    string name;
    int type;
};

#endif 
