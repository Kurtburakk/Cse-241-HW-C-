#ifndef WORLD_H
#define WORLD_H

#include "Robot.hpp"

const int GRIDSIZE = 10;
const int INITIALROBOT = 5;

class World 
{
    friend class Robot;
public:
    World();                // default constructor
    ~World();               // destructor 
    void putRobotWarArea(); // put robot area
    void start_war();       // game area
    //void display();
private:
    Robot* war_area[GRIDSIZE][GRIDSIZE];    // hold to robots 
};

#endif 