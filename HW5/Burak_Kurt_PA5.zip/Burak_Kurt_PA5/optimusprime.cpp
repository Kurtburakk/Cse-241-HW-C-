#include "optimusprime.hpp"
#include "humanic.hpp"

optimusprime::optimusprime(int creation_sequence_number): humanic(100, 100,std::to_string(creation_sequence_number))
{   
}
int optimusprime::getDamage()
{
    int damage=humanic::getDamage();
    if ((rand() % 100) < 15)
        damage*=2;
    cout << getType() << " attacks for " << damage << " points!" << endl;
    return damage;
}
string optimusprime::getType()
{
    return "optimusprime_" + name;  
}
int optimusprime::getHitpoint()
{
    return hitpoint;
}
void optimusprime::decreaseHitpoint(int damage)
{
    hitpoint = hitpoint - damage;
}
