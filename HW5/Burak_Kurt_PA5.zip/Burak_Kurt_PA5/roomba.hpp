#ifndef ROOMBA_H
#define ROOMBA_H

#include "Robot.hpp"

class roomba : public Robot 
{
public:
    roomba(int creation_sequence_number);
    string getType() override;
    int getDamage() override;
    int getHitpoint()override;
    void decreaseHitpoint(int damage)override;
};

#endif 
