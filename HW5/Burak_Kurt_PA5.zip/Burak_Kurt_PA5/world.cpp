#include "world.hpp"
#include "bulldozer.hpp"
#include "roomba.hpp"
#include "humanic.hpp"
#include "optimusprime.hpp"
#include "robocop.hpp"

#include <iostream>
#include <ctime>
#include <cstdlib>

using std::cout;
using std::endl;
using std::srand;

World::World()
{
    for (int i = 0; i < GRIDSIZE; ++i)
    {
        for (int j = 0; j < GRIDSIZE; ++j)
        {
            war_area[i][j] = nullptr;       // firstly each point equal to null
        }
    }
}
World::~World()
{
    for (int i = 0; i < GRIDSIZE; i++)
    {
        for (int j = 0; j < GRIDSIZE; j++)
        {
            if (war_area[i][j] != NULL)
                delete (war_area[i][j]);    // delete not empty each object 
        }
    }
}
void World::putRobotWarArea()
{
    srand(time(NULL));
    int robotCount = 0,i=0,j=0;
    int robotname=0;
    while (robotCount < INITIALROBOT*4)         // 20 robots
    {
        i = rand() % GRIDSIZE;
        j = rand() % GRIDSIZE;
        if (war_area[i][j] == nullptr) 
        {
            if (robotCount%4 == 0)
                war_area[i][j] = new optimusprime(robotname);   // create robots and put grid
            else if (robotCount%4 == 1)
                war_area[i][j] = new robocop(robotname);        // create robots and put grid
            else if (robotCount%4 == 2) 
                war_area[i][j] = new roomba(robotname);         // create robots and put grid
            else
            {
                war_area[i][j] = new bulldozer(robotname);      // create robots and put grid
                robotname++;                                    // provide go forward 0 1 2 ...                          
            }
            robotCount++;
        }
    }
}

void World::start_war()
{
    putRobotWarArea();
    int damage = 0, death = 0;
    int i = 0, j = 0, game_finish = 0;
    do
    {
        j = 0;
        do
        {
            //display();            // DISPLAY ROBOTS ON GRID
            if (i == 9 && j == 9)
            {
                j+=10;
                game_finish = 1;    // check last point
            }

            if (game_finish != 1)
            {
                death = 0;
                if (war_area[i][j] == nullptr)      // if it has not any object , we go next step
                    j++;    // next 
                else
                {
                    if (war_area[i][j + 1] == nullptr)  // if next step is empty , we swap this object to null 
                    {
                        war_area[i][j + 1] = war_area[i][j];
                        war_area[i][j] = nullptr;
                        j++; // next
                    }
                    else
                    {
                        while (death != 1)
                        {
                            damage = war_area[i][j]->getDamage();   // we hold to robot damage
                            cout << war_area[i][j]->getType() << "(" << war_area[i][j]->getHitpoint() << ") hits "      // write robots and their hitpoints
                                      << war_area[i][j + 1]->getType() << "(" << war_area[i][j + 1]->getHitpoint() << ") with " << damage << endl;
                            war_area[i][j + 1]->decreaseHitpoint(damage);
                            cout << "The new hitpoints of " << war_area[i][j + 1]->getType() << " is " << war_area[i][j + 1]->getHitpoint() << endl; // robot new hitpoint
                            if (war_area[i][j + 1]->getHitpoint() <= 0)
                            {
                                cout << war_area[i][j + 1]->getType() << " is dead. "<<endl<<endl;  // if second robot dead
                                war_area[i][j + 1] = nullptr;   // next step empty
                                death = 1;                      // check is the robot dead
                                j--;        // next step is empty
                            }
                            if (death != 1)
                            {
                                damage = war_area[i][j + 1]->getDamage();
                                cout << war_area[i][j + 1]->getType() << "(" << war_area[i][j + 1]->getHitpoint() << ") hits "
                                          << war_area[i][j]->getType() << "(" << war_area[i][j]->getHitpoint() << ") with " << damage << endl;
                                war_area[i][j]->decreaseHitpoint(damage);
                                cout << "The new hitpoints of " << war_area[i][j]->getType() << " is " << war_area[i][j]->getHitpoint() << endl;
                                if (war_area[i][j]->getHitpoint() <= 0)
                                {
                                    cout << war_area[i][j]->getType() << " is dead. "<<endl<<endl; // if first robot dead
                                    war_area[i][j] = nullptr; // previous step empty
                                    death = 1;
                                }
                            }
                        }
                        if ((i != GRIDSIZE - 1) && (j == GRIDSIZE - 1))     // compare end of current line with bottom line
                        {
                            if (war_area[i + 1][0] != nullptr)              // if bottom line not null object
                            { 
                                while (death != 1)
                                {
                                    damage = war_area[i][j]->getDamage();   // we hold to robot damage
                                    cout << war_area[i][j]->getType() << "(" << war_area[i][j]->getHitpoint() << ") hits "
                                              << war_area[i + 1][0]->getType() << "(" << war_area[i + 1][0]->getHitpoint() << ") with " << damage << endl;
                                    war_area[i + 1][0]->decreaseHitpoint(damage);
                                    cout << "The new hitpoints of " << war_area[i + 1][0]->getType() << " is " << war_area[i + 1][0]->getHitpoint() << endl;
                                    if (war_area[i + 1][0]->getHitpoint() <= 0)  // if second robot dead
                                    {
                                        cout << war_area[i+1][0]->getType() << " is dead. "<<endl <<endl; 
                                        war_area[i + 1][0] = nullptr;
                                        death = 1;
                                        j++;
                                    }
                                    if (death != 1)
                                    {
                                        damage = war_area[i + 1][0]->getDamage(); // we hold to robot damage
                                        cout << war_area[i + 1][0]->getType() << "(" << war_area[i + 1][0]->getHitpoint() << ") hits "
                                                  << war_area[i][j]->getType() << "(" << war_area[i][j]->getHitpoint() << ") with " << damage << endl;
                                        war_area[i][j]->decreaseHitpoint(damage); // decrease hitpoint
                                        cout << "The new hitpoints of " << war_area[i][j]->getType() << " is " << war_area[i][j]->getHitpoint() << endl;
                                        if (war_area[i][j]->getHitpoint() <= 0)  // if first robot dead
                                        {
                                            cout << war_area[i][j]->getType() << " is dead. "<< endl<<endl;
                                            war_area[i][j] = nullptr;
                                            death = 1;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                war_area[i + 1][0] = war_area[i][j];    // if next step null, swap its object
                                war_area[i][j] = nullptr;               // previous object equal null
                            }
                        }
                    }
                }
            }
        }while (j < GRIDSIZE);
        i++;
    }while (i < GRIDSIZE && game_finish == 0);
}
/*                        
void World::display()                       // display robots on grid
{
    for(int i=0;i<GRIDSIZE;i++)
    {
        for(int j=0;j<GRIDSIZE;j++)
        {
            if(war_area[i][j]!=nullptr)
            cout<<"X";
            else
            cout<<".";
        }
        cout<<endl;
    }
    cout<<endl;
}
*/