#include "roomba.hpp"
#include "Robot.hpp"

roomba::roomba(int creation_sequence_number): Robot(2, 3, 10,std::to_string(creation_sequence_number))
{ 
}
int roomba::getDamage()
{
    int  damage = Robot::getDamage();
    cout << getType() << " attacks for " << damage << " points!" << endl;
    int damage2 = Robot::getDamage();
    cout << getType() << " attacks for " << damage2 << " points!" << endl;
    return damage+damage2;
}

string roomba::getType()
{
    return "roomba_"+name;
}
int roomba::getHitpoint()
{
    return hitpoint;
}
void roomba::decreaseHitpoint(int damage)
{
    hitpoint = hitpoint - damage;
}