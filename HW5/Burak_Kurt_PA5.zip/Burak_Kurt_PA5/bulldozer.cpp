#include "bulldozer.hpp"
#include "Robot.hpp"

bulldozer::bulldozer(int creation_sequence_number): Robot(3, 50, 200,std::to_string(creation_sequence_number))
{
}
int bulldozer::getDamage()
{
    int damage=Robot::getDamage();
    cout << getType() << " attacks for " << damage << " points!" << endl;
    return damage;
}
string bulldozer::getType()
{
    return "bulldozer_"+name;
}
int bulldozer::getHitpoint()
{
    return hitpoint;
}
void bulldozer::decreaseHitpoint(int damage)
{
    hitpoint = hitpoint - damage;
}
