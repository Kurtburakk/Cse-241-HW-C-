#include "robocop.hpp"
#include "humanic.hpp"

robocop::robocop(int creation_sequence_number): humanic(30, 40,std::to_string(creation_sequence_number)) 
{
}
int robocop::getDamage()
{
    int damage = humanic::getDamage();
    cout << getType() << " attacks for " << damage << " points!" << endl;
    return damage;  
}
std::string robocop::getType()
{
    return "robocop_"+name;
}
int robocop::getHitpoint()
{
    return hitpoint;
}
void robocop::decreaseHitpoint(int damage)
{
    hitpoint = hitpoint - damage;
}
