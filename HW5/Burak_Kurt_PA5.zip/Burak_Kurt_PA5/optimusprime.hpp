#ifndef OPTIMUSPRIME_H
#define OPTIMUSPRIME_H

#include "humanic.hpp"

class optimusprime : public humanic
{
public:
    optimusprime(int creation_sequence_number);
    string getType() override;
    int getDamage() override;
    int getHitpoint()override;
    void decreaseHitpoint(int damage)override;
};

#endif
